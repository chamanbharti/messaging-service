package tdd.dao;

import java.sql.Connection;

import tdd.model.CleanUpTemplateDefinitionRequest;
import tdd.model.CleanUpTemplateRequest;

public class CleanUpTemplateDAO {
    
    private Connection conn;
    Object obj;
    public CleanUpTemplateDAO(Object object){
        this.obj = obj;
    }

    public CleanUpTemplateDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean isCleanUpTemplatesUnique(String name) {
        // Dummy implementation
        return true;
    }

    public int insert(CleanUpTemplateRequest request) {
        // Dummy implementation
        return 1;
    }

    public void insertDefinitions(CleanUpTemplateDefinitionRequest definitionRequest) {
        // Dummy implementation
    }
}
