package tdd.model;

public class CleanUpTemplateDefinitionRequest {
    private int fmtCode;
    public int getFmtCode() { return fmtCode; }
    public void setFmtCode(int fmtCode) { this.fmtCode = fmtCode; }
}
