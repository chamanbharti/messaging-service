package tdd.model;

import java.util.List;

public class CleanUpTemplateRequest {
    private String name;
    private int fmtCode;
    private List<CleanUpTemplateDefinitionRequest> definitions;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getFmtCode() { return fmtCode; }
    public void setFmtCode(int fmtCode) { this.fmtCode = fmtCode; }
    public List<CleanUpTemplateDefinitionRequest> getDefinitions() { return definitions; }
    public void setDefinitions(List<CleanUpTemplateDefinitionRequest> definitions) { this.definitions = definitions; }
}
