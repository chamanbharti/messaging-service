package tdd.model;

public class CleanUpTemplateUtils {
    public static final String UNIQUENESS_ERROR = "Template with this name already exists.";
}