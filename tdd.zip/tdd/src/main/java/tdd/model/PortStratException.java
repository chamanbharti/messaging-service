package tdd.model;

public class PortStratException extends Exception {
    public PortStratException(String message) {
        super(message);
    }
}