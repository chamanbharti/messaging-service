package tdd.service;

import tdd.model.CleanUpTemplateRequest;

// Dummy classes for compilation (replace with your actual classes)
interface CleanUpTemplateService {
    int createCleanUpTemplate(CleanUpTemplateRequest cleanUpTemplateRequest) throws Exception;
}