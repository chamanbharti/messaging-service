package tdd.service;

import javax.sql.DataSource;

import tdd.dao.CleanUpTemplateDAO;
import tdd.model.CleanUpTemplateDefinitionRequest;
import tdd.model.CleanUpTemplateRequest;
import tdd.model.CleanUpTemplateUtils;
import tdd.model.PortStratException;

import java.sql.Connection;

// Assume these are your DTOs and DAO
// import com.yourpackage.CleanUpTemplateRequest;
// import com.yourpackage.CleanUpTemplateDefinitionRequest;
// import com.yourpackage.CleanUpTemplateDAO;
// import com.yourpackage.PortStratException;
// import com.yourpackage.CleanUpTemplateUtils;

public class CleanUpTemplateServiceImpl implements CleanUpTemplateService {

    private final DataSource pfsRsDataSource;
    // If getSelectNext is truly part of the service, you'd likely want to keep it.
    // If it's a utility, it should be static or injected.
    // For this example, let's assume it's an internal helper method.

    public CleanUpTemplateServiceImpl(DataSource pfsRsDataSource) {
        this.pfsRsDataSource = pfsRsDataSource;
    }

    // This method likely resides in a utility class or should be injected.
    // For now, let's make it package-private or protected for testing if it's internal.
    // Ideally, mock this utility.
    // For the sake of demonstration, I'll put it here.
    public int getSelectNext(String tableName, String columnName) {
        // Simulate actual logic, or if this comes from a DB call, you'd need another DAO.
        return 12345; // Example format code
    }

    @Override
    public int createCleanUpTemplate(CleanUpTemplateRequest cleanUpTemplateRequest) throws PortStratException {
        Connection conn = null;
        int result = 0;
        int fmtCode = getSelectNext("file_fmt", "cd_fmt"); // This assumes getSelectNext is part of the service.
        cleanUpTemplateRequest.setFmtCode(fmtCode);

        try {
            conn = pfsRsDataSource.getConnection();

            // This is the tricky part for mocking. Ideally, CleanUpTemplateDAO
            // should be injected or created via a factory.
            // For now, we'll use a trick in the test to mock its behavior.
            CleanUpTemplateDAO cleanUpTemplateDAO = new CleanUpTemplateDAO(conn);

            if (!cleanUpTemplateDAO.isCleanUpTemplatesUnique(cleanUpTemplateRequest.getName())) {
                throw new PortStratException(CleanUpTemplateUtils.UNIQUENESS_ERROR);
            }

            result = cleanUpTemplateDAO.insert(cleanUpTemplateRequest);

            if (cleanUpTemplateRequest.getDefinitions() != null) {
                for (CleanUpTemplateDefinitionRequest definitionRequest : cleanUpTemplateRequest.getDefinitions()) {
                    definitionRequest.setFmtCode(fmtCode);
                    cleanUpTemplateDAO.insertDefinitions(definitionRequest);
                }
            }
        } catch (PortStratException e) {
            throw e; // Re-throw the specific exception
        } catch (Exception e) {
            // Log the exception, handle it appropriately, or re-throw a generic exception
            System.err.println("An error occurred during cleanup template creation: " + e.getMessage());
            // You might want to throw a custom runtime exception here,
            // or a more specific checked exception.
            // For 100% coverage, we need to ensure this catch block is hit.
            throw new RuntimeException("Failed to create cleanup template due to an internal error.", e);
        } finally {
            if (conn != null) {
                try {
                    conn.close(); // Ensure connection is closed
                } catch (Exception e) {
                    System.err.println("Error closing connection: " + e.getMessage());
                }
            }
        }
        return result;
    }
}